#!/bin/bash
# Single command: streamlit run app.py
streamlit run app.py
