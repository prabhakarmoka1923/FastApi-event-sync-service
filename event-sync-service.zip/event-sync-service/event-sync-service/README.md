# Event Sync Service

Unified view of client meetings from **CRM** (`data/crm_events.json`) + **Calendar** (`data/calendar_events.json`).

## Quick start — single command
```bash
pip install -r requirements.txt
streamlit run app.py
# -> http://localhost:8501
```
Optional API backend (separate terminal):
```bash
uvicorn api:app --reload --port 8000
# GET /api/meetings  /api/meetings/{id}  /api/stats  /health
```
> Streamlit works without the API running — `app.py` calls the same `src/reconcile.py` directly.

## Project structure
```
app.py                 # Streamlit frontend
api.py                 # FastAPI REST API
src/reconcile.py       # ingestion + normalisation + matching + conflicts (pure logic)
data/crm_events.json   # Source A - CRM
data/calendar_events.json  # Source B - Calendar
requirements.txt  run.sh  README.md
docs/MATCHING.md  docs/AI_COLLABORATION.md
```

## How reconciliation works
Full rules: `docs/MATCHING.md` + docstring in `src/reconcile.py`.
- **Match:** same date + people/company anchor + title similarity + time proximity. Score >= 50, greedy best-first, each record matched at most once.
- **Time is soft, not a hard gate.** CRM times are local wall-clock, Calendar mixes naive + `Z`. Example: Crestview DD — CRM 14:00 vs Calendar 19:00Z — same meeting, timezone shift. A strict 30-min gate would miss it.
- **Conflicts are never auto-resolved.** Both values kept with provenance; UI shows CRM vs Calendar side-by-side + a conflict badge.
- **Duplicates:** CAL-A5 / CAL-A6 (Pinnacle, same date/client, 30 min apart) — A6 flagged `duplicate_of A5`, not a separate meeting.
- **Malformed rows never crash:** CRM-1008 date `03-15/2025`, CRM-1007 missing time, CAL-A11 missing location/description + `20:00` end_time, CAL-A16 attendee `raj.patel[at]atlasvc.com` — all parsed with fallbacks and listed under Issues.
- **Recurring:** each Weekly Sync / Pipeline Review occurrence kept as its own meeting.

## Audit — matched pairs (verify against raw JSON)
| CRM | Calendar | Evidence |
|---|---|---|
| CRM-1001 Meridian Q1 Review | CAL-A1 | same date, David Park attendee, title |
| CRM-1002 Summit Walkthrough | CAL-A2 | same date/time, Mark Johnson attendee — **CONFLICT: CRM In-Person NYC vs Calendar Zoom** |
| CRM-1004 Crestview DD | CAL-A4 | same date, Patricia attendee, same location — **CONFLICT: time 14:00 vs 19:00Z (tz)** |
| CRM-1005 Pinnacle Update | CAL-A5 | same date/time, Kevin attendee |
| CRM-1006 Pipeline Review | CAL-A7 | internal, same date/time/location |
| CRM-1007 Meridian Follow-up | CAL-A8 | same date, David attendee (CRM time missing) |
| CRM-1008 Atlas Lunch | CAL-A9 | same date (after fixing `03-15/2025`), Lisa attendee, same venue |
| CRM-1009 Board Prep | CAL-A10 | same date/time/location — **CONFLICT: CRM Cancelled vs Calendar confirmed** |
| CRM-1011 Horizon Review | CAL-A12 | same date/time, Elena attendee |
| CRM-1012 Granite Co-Invest | CAL-A13 | same date/time, Thomas attendee |
| CRM-1013 LPAC Prep | CAL-A14 | internal, same date/time/location |
| CRM-1014 Evergreen Check-in | CAL-A15 | same date/time, Michael attendee |
| CRM-1015 Atlas Pitch | CAL-A16 | same date/time, Lisa attendee — attendee email malformed, flagged |
| CRM-1016 ESG Discussion | CAL-A17 | same date, Karen attendee — **CONFLICT: CRM 13:00 vs Calendar 15:00** |
| CRM-1017 Closing Dinner | CAL-A20 | same date/time, Fund VII — venue variants treated as same |
| CRM-1018 Crestview Follow-up | CAL-A21 | same date/time, Patricia attendee |
| CRM-1019 QBR | CAL-A22 | internal, same date/time/location |

CRM-only: CRM-1003 Lakeshore, CRM-1010 Northwind Strategy, CRM-1020 Northwind Fund VII.
Calendar-only: CAL-A3/A18 Weekly Syncs, CAL-A11 Client Reception, CAL-A19 Roadshow Prep, CAL-A6 duplicate.

## Filters in UI
Search, source, conflicts-only, duplicates-only, issues-only; detail pane shows CRM vs Calendar JSON, conflicts, match evidence, issues.

## AI collaboration
See `docs/AI_COLLABORATION.md` for brainstorming/planning log.
