# AI Collaboration Log (transparency)

## Brainstorming (with Meta AI)
- Problem restated: two sources, no shared ID, fuzzy times, conflicts, duplicates, malformed rows. No spec for tie-breaking -> decision: never silently pick a winner.
- Options considered: (a) exact-ID join - impossible; (b) strict time+title join - misses Crestview tz shift; (c) scored fuzzy match - chosen.
- Conflict options: last-write-wins / Calendar-wins / CRM-wins / surface both - chose surface both, UI side-by-side.
- Duplicate options: delete / merge silently / flag - chose flag + keep visible as duplicate_of.

## Planning
- Architecture: src/reconcile.py (pure logic, testable) + api.py (FastAPI) + app.py (Streamlit, calls reconcile directly so one command works).
- Verification: run reconcile, check stats, manually audit every matched pair against raw JSON (see README audit table).

## What AI did / what human should do
- AI drafted code + docs. Human should: run `streamlit run app.py`, spot-check the conflict list, decide real-world tie-break policy with the sales team (e.g. Calendar wins for location, CRM wins for client) before any auto-resolution is added.
