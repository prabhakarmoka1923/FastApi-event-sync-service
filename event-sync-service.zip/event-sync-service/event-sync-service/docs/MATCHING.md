# Matching & conflict rules

See README + src/reconcile.py docstring. Summary:
- Match key: same date + people/company anchor + title similarity + time proximity (score >=50, greedy best-first).
- Time is soft: CRM 14:00 vs Calendar 19:00Z (Crestview DD) still matches via people+company+location.
- Conflicts: location (normalised, 'HQ - Conference Room B' == 'Conference Room B'), start >15 min, Cancelled vs confirmed.
- Known conflicts surfaced: Summit Advisors (CRM In-Person NYC Office vs Calendar Zoom), Crestview (time), ESG (CRM 13:00 vs Calendar 15:00), Board Prep (CRM Cancelled vs Calendar confirmed), Fund VII Dinner (The Palm - DC vs The Palm Restaurant - same venue, NOT flagged).
- Intra-source duplicate: CAL-A5 vs CAL-A6 Pinnacle (same date/client, 30 min apart) - A6 flagged duplicate_of A5.
- Malformed: CRM-1008 date '03-15/2025', CRM-1007 missing time, CAL-A11 missing location/description + malformed end_time, CAL-A16 attendee 'raj.patel[at]atlasvc.com', CRM-1010 empty notes.
- CRM-only: Lakeshore, Northwind x2. Calendar-only: Weekly Syncs, Client Reception, etc.
