
"""Event Sync Service - ingestion, normalisation, reconciliation.

Design decisions (documented in docs/AI_COLLABORATION.md + README):
- No shared ID -> match on (date + people/company + title similarity + time proximity).
- Time is a *score*, not a hard gate: CRM times are local wall-clock, Calendar
  times mix naive + 'Z'. Crestview DD is 14:00 CRM vs 19:00Z Calendar (same
  meeting, timezone shift) - a strict 30-min gate would miss it.
- Conflicts are NEVER silently resolved. Both values are kept with provenance
  and a conflict flag; the UI shows CRM vs Calendar side-by-side.
- Intra-source duplicates: two Calendar events, same date, same core attendees,
  start within 60 min, same company -> flagged, earliest-created kept as
  canonical, other listed as duplicate_of (not a separate unified meeting).
- Malformed data: never crash. Every parse failure is recorded in `issues`
  and the record is kept with the raw value preserved.
"""
import json, re, difflib
from pathlib import Path
from datetime import datetime, timedelta

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def parse_datetime(raw, date_only=False):
    """Parse many formats. Returns (datetime|None, issue|None)."""
    if raw is None or (isinstance(raw,str) and not raw.strip()):
        return None, "missing datetime"
    s=str(raw).strip()
    # CRM malformed "03-15/2025" -> "2025-03-15"
    m=re.match(r"^(\d{2})-(\d{2})/(\d{4})$", s)
    if m: s=f"{m.group(3)}-{m.group(1)}-{m.group(2)}"
    for fmt in ("%Y-%m-%dT%H:%M:%S%z","%Y-%m-%dT%H:%M:%S","%Y-%m-%dT%H:%M",
                "%Y-%m-%d %H:%M:%S","%Y-%m-%d %H:%M","%Y-%m-%d"):
        try:
            dt=datetime.strptime(s.replace("Z","+0000") if s.endswith("Z") else s, fmt)
            return dt.replace(tzinfo=None), None
        except ValueError: pass
    # "2025-03-14T20:00" handled above; fallback dateutil-free
    try:
        dt=datetime.fromisoformat(s.replace("Z","+00:00"))
        return dt.replace(tzinfo=None), None
    except Exception:
        return None, f"unparseable datetime: {raw!r}"

def normalise_location(loc):
    if not loc: return ""
    s=str(loc).lower()
    s=re.sub(r"https?://\S+","",s); s=re.sub(r"[^a-z0-9 ]"," ",s)
    return re.sub(r"\s+"," ",s).strip()

def location_conflict(a,b):
    na, nb = normalise_location(a), normalise_location(b)
    if not na or not nb: return False
    if na==nb: return False
    # "HQ - Conference Room B" vs "Conference Room B" / "Boston Office - Room 301" vs "Boston Office"
    if na in nb or nb in na: return False
    # Zoom vs In-Person style clash is a real conflict, handled by token check:
    # if they share a strong token (room, office, grille, palm) -> not a conflict
    tokens_a=set(na.split())-{"hq","office","room","the","conference"}
    tokens_b=set(nb.split())-{"hq","office","room","the","conference"}
    if tokens_a & tokens_b: return False
    return True

def tokens(s): return set(re.findall(r"[a-z0-9]+", (s or "").lower())) - {"q1","q2","the","a","an","and","for","with","re","meeting","call","discussion","review","update","session","prep"}
def title_sim(a,b):
    return difflib.SequenceMatcher(None,(a or "").lower(),(b or "").lower()).ratio()
def email_prefix(name):
    return re.sub(r"[^a-z]","", (name or "").lower().split()[0]) if name else ""
def company_key(c):
    t=tokens(c); t-={"capital","group","holdings","partners","ventures","investments","institutional","wealth"}
    return t

def load_raw():
    crm=json.loads((DATA_DIR/"crm_events.json").read_text())
    cal=json.loads((DATA_DIR/"calendar_events.json").read_text())
    return crm, cal

def normalise_crm(r):
    issues=[]
    dt,_=parse_datetime(r.get("meeting_date"))
    if dt is None: issues.append(f"bad meeting_date {r.get('meeting_date')!r}")
    t=r.get("meeting_time")
    start=None
    if dt is not None:
        if t:
            try: hh,mm=map(int,str(t).split(":")); start=dt.replace(hour=hh,minute=mm)
            except Exception: issues.append(f"bad meeting_time {t!r}")
        else: issues.append("missing meeting_time - matched on date+people only")
    return {"source":"CRM","source_id":r.get("crm_id"),"raw":r,"title":r.get("subject") or "",
      "client_name":r.get("client_name"),"client_company":r.get("client_company"),
      "owner":r.get("relationship_owner"),"start":start,"date":dt.date() if dt else None,
      "location":r.get("location"),"meeting_type":r.get("meeting_type"),
      "status":r.get("status"),"notes":r.get("notes") or r.get("description") or "",
      "attendees":[],"issues":issues,"created_at":r.get("created_at")}

def normalise_cal(r):
    issues=[]
    start,err=parse_datetime(r.get("start_time"))
    if err: issues.append(err)
    end,err2=parse_datetime(r.get("end_time"))
    if err2: issues.append(f"bad end_time {r.get('end_time')!r} (kept raw)")
    atts=r.get("attendees") or []
    for a in atts:
        if not EMAIL_RE.match(str(a)):
            issues.append(f"malformed attendee {a!r} (not a valid email - kept, not matched as email)")
    if not atts: issues.append("no attendees")
    if r.get("location") is None: issues.append("missing location")
    if r.get("description") is None: issues.append("missing description")
    return {"source":"Calendar","source_id":r.get("event_id"),"raw":r,"title":r.get("title") or "",
      "client_name":None,"client_company":None,"owner":r.get("organizer"),
      "start":start,"date":start.date() if start else None,"end":end,
      "location":r.get("location"),"meeting_type":None,"status":r.get("status"),
      "notes":r.get("description") or "","attendees":atts,"issues":issues,
      "created_at":r.get("created_at"),"is_recurring":r.get("is_recurring")}

def match_score(crm, cal):
    """0-100. Requires same date + a people/company anchor."""
    if not crm["date"] or not cal["date"] or crm["date"]!=cal["date"]: return 0, []
    reasons=[]
    score=0
    # people anchor: client email prefix in attendees, or owner == organiser
    prefix=email_prefix(crm["client_name"])
    cal_emails=[a.lower() for a in cal["attendees"]]
    if prefix and any(a.startswith(prefix+".") or a.startswith(prefix+"@") for a in cal_emails):
        score+=40; reasons.append(f"client {crm['client_name']} in calendar attendees")
    # company anchor: company tokens in calendar title
    ck=company_key(crm["client_company"])
    if ck and ck & tokens(cal["title"]):
        score+=35; reasons.append(f"company {crm['client_company']} in calendar title")
    # internal meetings: same date + same start + same location is a strong anchor
    # (covers QBR = Quarterly Business Review, LPAC = LP Advisory Committee)
    if not crm["client_name"] and not crm["client_company"]:
        if crm["start"] and cal["start"] and crm["start"]==cal["start"] and crm["location"] and cal["location"] and normalise_location(crm["location"])==normalise_location(cal["location"]):
            score+=50; reasons.append("internal: same date + same start + same location")
        # acronym: initials of one title appear as a token in the other
        def acronym(s): return "".join(w[0] for w in re.findall(r"[A-Za-z]+",(s or "")) if w.lower() not in {"a","an","the","and","for"})
        if acronym(crm["title"]).lower() in tokens(cal["title"]) or acronym(cal["title"]).lower() in tokens(crm["title"]):
            score+=30; reasons.append("acronym match (QBR/LPAC)")
    if not crm["client_name"] and not crm["client_company"]:
        if tokens(crm["title"]) & tokens(cal["title"]):
            score+=45; reasons.append("internal: title overlap + same owner/organiser")
        if cal["location"] and crm["location"] and normalise_location(cal["location"])==normalise_location(crm["location"]):
            score+=15; reasons.append("same location")
    # title similarity
    ts=title_sim(crm["title"], cal["title"])
    if ts>0.35: score+= round(ts*20); reasons.append(f"title similarity {ts:.2f}")
    # time proximity (soft)
    if crm["start"] and cal["start"]:
        diff=abs((crm["start"]-cal["start"]).total_seconds())/60
        if diff<=15: score+=15; reasons.append(f"start times {diff:.0f} min apart")
        elif diff<=120: score+=5; reasons.append(f"start times {diff:.0f} min apart (possible tz shift)")
        elif diff<=360: reasons.append(f"start times {diff:.0f} min apart - large, likely tz shift (Crestview pattern)")
        else: score-=10
    return score, reasons

def reconcile():
    crm_raw, cal_raw = load_raw()
    crms=[normalise_crm(r) for r in crm_raw]
    cals=[normalise_cal(r) for r in cal_raw]
    # --- intra-source duplicate detection (Calendar) ---
    duplicate_of={}  # cal source_id -> canonical cal source_id
    for i,a in enumerate(cals):
        for b in cals[i+1:]:
            if a["date"] and a["date"]==b["date"] and a["start"] and b["start"] and abs((a["start"]-b["start"]).total_seconds())<=3600:
                core_a=set(x.lower() for x in a["attendees"]); core_b=set(x.lower() for x in b["attendees"])
                if core_a and core_a<=core_b or core_b<=core_a:
                    if tokens(a["title"]) & tokens(b["title"]) or company_key(a["title"]) & company_key(b["title"]):
                        # keep earliest created_at as canonical
                        canon, dup = (a,b) if (a["created_at"] or "")<=(b["created_at"] or "") else (b,a)
                        duplicate_of[dup["source_id"]]=canon["source_id"]
    # --- cross-source matching (greedy, best score first) ---
    pairs=[]
    for c in crms:
        for k in cals:
            if k["source_id"] in duplicate_of: continue
            s,why=match_score(c,k)
            if s>=50: pairs.append((s,c,k,why))
    pairs.sort(key=lambda x:-x[0])
    used_crm, used_cal=set(), set(); matches=[]
    for s,c,k,why in pairs:
        if c["source_id"] in used_crm or k["source_id"] in used_cal: continue
        used_crm.add(c["source_id"]); used_cal.add(k["source_id"]); matches.append((s,c,k,why))
    # --- build unified list ---
    unified=[]
    def conflicts(c,k):
        out=[]
        if c and k:
            if location_conflict(c["location"],k["location"]): out.append({"field":"location","crm":c["location"],"calendar":k["location"],"note":"Different venues - verify which is correct"})
            if c["start"] and k["start"] and abs((c["start"]-k["start"]).total_seconds())>900:
                out.append({"field":"start_time","crm":str(c["start"]),"calendar":str(k["start"]),"note":"Start times differ by >15 min - likely timezone / entry error"})
            if (c["status"] or "").lower() not in (k["status"] or "").lower() and (c["status"] or "").lower()!="confirmed":
                # only flag meaningful status clashes (e.g. Cancelled vs confirmed)
                if { (c["status"] or "").lower(), (k["status"] or "").lower()} & {"cancelled","canceled"}:
                    out.append({"field":"status","crm":c["status"],"calendar":k["status"],"note":"One source says cancelled"})
        return out
    for s,c,k,why in matches:
        cf=conflicts(c,k)
        unified.append({"unified_id":f"U-{c['source_id']}-{k['source_id']}","title":k["title"] or c["title"],
          "client_name":c["client_name"],"client_company":c["client_company"],
          "owner":c["owner"],"start":str(k["start"] or c["start"]),"date":str(c["date"]),
          "location_crm":c["location"],"location_calendar":k["location"],
          "sources":["CRM","Calendar"],"crm_id":c["source_id"],"calendar_id":k["source_id"],
          "match_score":s,"match_reasons":why,"conflicts":cf,"has_conflict":bool(cf),
          "issues":sorted(set(c["issues"]+k["issues"])),"is_recurring":k.get("is_recurring"),
          "crm_status":c["status"],"calendar_status":k["status"],
          "attendees":k["attendees"],"notes_crm":c["notes"],"notes_calendar":k["notes"]})
    for c in crms:
        if c["source_id"] not in used_crm:
            unified.append({"unified_id":f"U-{c['source_id']}-ONLY","title":c["title"],"client_name":c["client_name"],
              "client_company":c["client_company"],"owner":c["owner"],"start":str(c["start"]),"date":str(c["date"]),
              "location_crm":c["location"],"location_calendar":None,"sources":["CRM"],"crm_id":c["source_id"],
              "calendar_id":None,"match_score":None,"match_reasons":["No calendar counterpart found"],
              "conflicts":[],"has_conflict":False,"issues":c["issues"],"is_recurring":False,
              "crm_status":c["status"],"calendar_status":None,"attendees":[],"notes_crm":c["notes"],"notes_calendar":""})
    for k in cals:
        if k["source_id"] in used_cal: continue
        if k["source_id"] in duplicate_of:
            unified.append({"unified_id":f"U-{k['source_id']}-DUP","title":k["title"],"client_name":None,
              "client_company":None,"owner":k["owner"],"start":str(k["start"]),"date":str(k["date"]),
              "location_crm":None,"location_calendar":k["location"],"sources":["Calendar"],"crm_id":None,
              "calendar_id":k["source_id"],"match_score":None,
              "match_reasons":[f"Intra-source duplicate of {duplicate_of[k['source_id']]} - not a separate meeting"],
              "conflicts":[],"has_conflict":False,"issues":k["issues"]+["intra-source duplicate"],
              "is_recurring":k.get("is_recurring"),"crm_status":None,"calendar_status":k["status"],
              "attendees":k["attendees"],"notes_crm":"","notes_calendar":k["notes"],"duplicate_of":duplicate_of[k["source_id"]]})
        else:
            unified.append({"unified_id":f"U-{k['source_id']}-ONLY","title":k["title"],"client_name":None,
              "client_company":None,"owner":k["owner"],"start":str(k["start"]),"date":str(k["date"]),
              "location_crm":None,"location_calendar":k["location"],"sources":["Calendar"],"crm_id":None,
              "calendar_id":k["source_id"],"match_score":None,"match_reasons":["No CRM counterpart found"],
              "conflicts":[],"has_conflict":False,"issues":k["issues"],"is_recurring":k.get("is_recurring"),
              "crm_status":None,"calendar_status":k["status"],"attendees":k["attendees"],"notes_crm":"","notes_calendar":k["notes"]})
    unified.sort(key=lambda x:(x["date"] or "", x["start"] or ""))
    stats={"crm_total":len(crms),"calendar_total":len(cals),"matched":len(matches),
      "crm_only":sum(1 for u in unified if u["sources"]==["CRM"]),
      "calendar_only":sum(1 for u in unified if u["sources"]==["Calendar"]),
      "with_conflicts":sum(1 for u in unified if u["has_conflict"]),
      "duplicates":len(duplicate_of),"unified_total":len(unified)}
    return {"meetings":unified,"stats":stats,"duplicate_map":duplicate_of}

if __name__=="__main__":
    import pprint; r=reconcile(); print(r["stats"])
    for m in r["meetings"]: print(m["unified_id"], m["title"], m["sources"], "conflicts:", len(m["conflicts"]), m["issues"])
