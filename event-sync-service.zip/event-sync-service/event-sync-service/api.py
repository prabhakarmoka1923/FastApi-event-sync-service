
"""REST API backend (FastAPI). Run: uvicorn api:app --reload --port 8000
Streamlit (app.py) calls the same reconcile() directly so the UI works
with a single command even without the API running."""
from fastapi import FastAPI, Query
from src.reconcile import reconcile
app=FastAPI(title="Event Sync Service", version="1.0.0")
@app.get("/health")
def health(): return {"status":"ok"}
@app.get("/api/meetings")
def meetings(source: str|None=Query(default=None), conflicts_only: bool=False, search: str|None=None):
    data=reconcile(); items=data["meetings"]
    if source: items=[m for m in items if source in m["sources"]]
    if conflicts_only: items=[m for m in items if m["has_conflict"]]
    if search:
        q=search.lower(); items=[m for m in items if q in (m["title"] or "").lower() or q in (m["client_company"] or "").lower() or q in (m["client_name"] or "").lower()]
    return {"stats":data["stats"],"count":len(items),"meetings":items}
@app.get("/api/meetings/{unified_id}")
def one(unified_id: str):
    data=reconcile()
    for m in data["meetings"]:
        if m["unified_id"]==unified_id: return m
    return {"error":"not found"}
@app.get("/api/stats")
def stats(): return reconcile()["stats"]
