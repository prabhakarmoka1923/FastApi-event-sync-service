
"""Streamlit frontend. Run: streamlit run app.py  (single command, see README)"""
import streamlit as st, pandas as pd
from src.reconcile import reconcile
st.set_page_config(page_title="Event Sync Service", layout="wide")
st.title("📅 Event Sync Service — Unified Meetings")
st.caption("CRM + Calendar reconciled. Conflicts are never auto-resolved — both values are shown with provenance.")
data=reconcile(); meetings=data["meetings"]; stats=data["stats"]
c1,c2,c3,c4,c5=st.columns(5)
c1.metric("Unified meetings", stats["unified_total"]); c2.metric("Matched (both sources)", stats["matched"])
c3.metric("CRM only", stats["crm_only"]); c4.metric("Calendar only", stats["calendar_only"]); c5.metric("⚠️ With conflicts", stats["with_conflicts"])
st.info(f"Intra-source duplicates flagged: {stats['duplicates']} — see the Duplicate flag in the table / detail view.")
# Filters
with st.sidebar:
    st.header("Filters")
    q=st.text_input("Search title / client / company")
    src=st.selectbox("Source", ["All","Both sources","CRM only","Calendar only"])
    only_conf=st.checkbox("Conflicts only")
    only_dup=st.checkbox("Duplicates only")
    only_issues=st.checkbox("Records with data-quality issues")
filtered=meetings
if q:
    ql=q.lower(); filtered=[m for m in filtered if ql in (m["title"] or "").lower() or ql in (m["client_company"] or "").lower() or ql in (m["client_name"] or "").lower()]
if src=="Both sources": filtered=[m for m in filtered if len(m["sources"])==2]
if src=="CRM only": filtered=[m for m in filtered if m["sources"]==["CRM"]]
if src=="Calendar only": filtered=[m for m in filtered if m["sources"]==["Calendar"]]
if only_conf: filtered=[m for m in filtered if m["has_conflict"]]
if only_dup: filtered=[m for m in filtered if "duplicate_of" in m]
if only_issues: filtered=[m for m in filtered if m["issues"]]
st.subheader(f"Meetings ({len(filtered)})")
rows=[{"ID":m["unified_id"],"Date":m["date"],"Start":m["start"],"Title":m["title"],
  "Client":m["client_name"] or "—","Company":m["client_company"] or "—","Owner":m["owner"] or "—",
  "Sources":" + ".join(m["sources"]),"CRM":m["crm_id"] or "—","Calendar":m["calendar_id"] or "—",
  "⚠️ Conflict":"YES" if m["has_conflict"] else "","Duplicate":f"dup of {m.get('duplicate_of')}" if "duplicate_of" in m else "",
  "Issues":"; ".join(m["issues"]) if m["issues"] else ""} for m in filtered]
st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
st.divider(); st.subheader("🔍 Meeting detail — provenance & conflicts")
choice=st.selectbox("Select a meeting", [f"{m['date']} | {m['title']} | {m['unified_id']}" for m in filtered] or ["No meetings match filters"])
if filtered:
    m=next(x for x in filtered if x["unified_id"] in choice)
    a,b=st.columns(2)
    with a: st.markdown("**CRM**"); st.json({"crm_id":m["crm_id"],"location":m["location_crm"],"status":m["crm_status"],"notes":m["notes_crm"]})
    with b: st.markdown("**Calendar**"); st.json({"calendar_id":m["calendar_id"],"location":m["location_calendar"],"status":m["calendar_status"],"attendees":m["attendees"],"notes":m["notes_calendar"]})
    if m["conflicts"]:
        st.warning("Conflicts found — human review needed:")
        for cf in m["conflicts"]: st.markdown(f"- **{cf['field']}**: CRM = `{cf['crm']}` vs Calendar = `{cf['calendar']}` — {cf['note']}")
    else: st.success("No conflicts for this meeting.")
    if m["match_reasons"]: st.markdown("**Match evidence:** " + "; ".join(m["match_reasons"]) + (f" (score {m['match_score']})" if m["match_score"] else ""))
    if m["issues"]: st.markdown("**Data-quality issues:** " + "; ".join(m["issues"]))
    if m["is_recurring"]: st.markdown("🔁 Recurring calendar event — each occurrence kept as its own meeting.")
st.divider(); st.subheader("📖 How matching works")
st.markdown(open("docs/MATCHING.md").read() if __import__("pathlib").Path("docs/MATCHING.md").exists() else "")
